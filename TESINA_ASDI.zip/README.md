# VHDL-archietture-dei-sitemi-digitali
Exercise in VHDL (VIVADO)
